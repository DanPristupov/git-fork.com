###Fork v0.0.5

Changelog:
- Impelemented the create branch feature
- Implemented local branch checkout
- Implemented merge (merge conflicts are not handled yet)
- Added the application icon to all the controls
- Show git error details dialog on git error
- Perform all the UI-blocking operations in a background thread

+ Improved user experience for Push and Fetch windows
+ Highlight the current branch label in the revision list control
+ Improved highlighting in the diff control

* First row was unselected after repository opening
* Fork crashed on partially copied files diff parsing

###Fork v0.0.4

Today I'm excited to announce first technical preview build which I'm going to show to my friends.

In order to make the public beta closer, I added a feedback button which allows to report a bug or problem right from the application. This will allow me to react to issues more quickly and fix them ASAP. I'm really looking forward to receive the feedback and contributions.

Changelog:
- Finished branch graph drawing.
- Impelemnted a possibility to send feedback or bug report from the application.
- Created toolbar icons for each operations (sidebar icons to go)
- Created status icons for changed files (modified/added/deleted/renamed).
- Implemented highlighting of exact differences between rows in diff control
- Implemented dynamic avatar generator for users without gravatar account.

+ Improved selection colors and made them more contrast
+ Made user interface more clean, removed redundant noise.

###Fork v0.0.3

Even while this isn't directly related to the new version, I want to mention that we created a draft of the Fork website, which you are reading now. There are a lot of things to do and we'll be working on the improvements.

The new build brings great improvements to the main window.
- I have implemented navigation sidebar which shows information about tags and local and remote branches.
- Added a column with branch graph visualisation. There is still a room for improvements. Will continue working on that next week.
- Created Fetch, Pull and Push icons

+ Replaced toolbar items with buttons

* Commit list view now highlights the HEAD revision correctly after commit
* Removed spellchecker marks from the diff view
* Commit list now displays revisions from all the branches
* Got rid of all compiler warnings

###GitClient v0.0.2 - new features and new name
I'm happy to say that we found a nice and simple name for our git client. We called it Fork. A small blog will be created soon.

We'd spent a week using the v0.0.1 build and created a list of issues and improvements which I'm going to perform next week.

I'm just about to build a version 0.0.2 which contains a lot of new features and fixes.
####ChangeLog:
- Significantly improved the commit description view
![](https://dl.dropboxusercontent.com/s/6pqzbohwolp1jb4/2016-04-24%20at%2010.50.png)
- Implemented the commit change details view
![](https://dl.dropboxusercontent.com/s/9gvn8lut6fmu87u/2016-04-24%20at%2010.58.png)
- Commit list renders the branch and tag labels now. The HEAD revision is marked with bold font.
![](https://dl.dropboxusercontent.com/s/rdkhguvdt84al4q/2016-04-24%20at%2011.07.png)

- Grayed out the system information lines in diff view
* Fixed the coloring issues in diff view with files with mixed \n and \r\n newline symbols.
* Fixed crash on opening a non existing repository.

This is the last time when I use the GitClient codename. Next week I'm going to rename all the assets correspondingly.

###GitClient v0.0.1

This is a first release which will be used by us internally as a main git client.
This iteration brings significant improvements to commit dialog.

![](https://dl.dropboxusercontent.com/s/padn2fy71irisc6/2016-04-17%20at%2011.24.png)

####ChangeLog:
- Improved look and feel of the commit dialog.
There is a number of large improvements in the commit dialog.
  - One of the main point is the partial stage/unstage/reset.
     * I switched from naive diff modification to compiler-like algorithm which creates AST, modifies it and then exports the result.
     * Partial stage and unstage seem to be working correct. But some bugs still exist.
     * I added possibility to reset (discard) whole files and separate changelines. The partial reset is not 100% stable yet and will need some attention in the feature.
     * Implemented reset for staged/unstaged. Partial reset is supported too, but still has some bugs.
     * It's worth saying that I implemented partial stage and reset even for new (i.e. non tracked) files
     * Covered majority of parsing and AST transformation cases by unit tests

  - Completely reworked the design and layout of the commit window.
  - I have also added system file type icons to the file list.
  - Added context menu to the file list
  - Automatically close the commit dialog after commit if there the unstaged file list is empty
  - Split commit message field into two: commit subject and commit description.
  - Implemented possibility to amend the last commit.
    ![](https://dl.dropboxusercontent.com/s/q5eaucyzxx77mfo/2016-04-17%20at%2011.26.png)

The main window has some improvements too:
- I added the possibility to open any repository on the disk using the standard open directory dialog.
- Created a design mockup of the main window for the next iteration/sprint
- When application gets awakes from being unfocused the current view (such as main window or commit dialog) will be refreshed. That feature crashes the application sometimes, need to fix that.

###GitClient v0.0.0

The initial release. More like a proof of concept.

####Changelog:
- Implemented draft of the revision list
- Implemented draft of the commit window. There is a possibility to stage/unstage files and make commits. Partial stage/unstage are very buggy and need a lot of improvements.